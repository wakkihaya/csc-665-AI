Name: Hayato Waki
ID: 920753948
Description:
About addition.py adnd buyLotsOfFruit.py, I just looked up the keys and values by using 'for' loop, and confirmed if they matched
to the given lists by using 'if'.
About shopSmart.py, I got the dictionary who has set of the name of shop and the total cost to buy fruit in that shop,
and then I used the 'min' method to get the name of shop which has the minimum total cost.